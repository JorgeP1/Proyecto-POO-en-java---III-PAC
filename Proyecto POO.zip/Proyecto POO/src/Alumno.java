/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class Alumno extends Persona {
   public String NumeroRegistro;

    public Alumno(String Identidad) {
        super(Identidad);
    }

    public Alumno(String NumeroRegistro, String Identidad) {
        super(Identidad);
        this.NumeroRegistro = NumeroRegistro;
    }

    public String getNumeroRegistro() {
        return NumeroRegistro;
    }

    public void setNumeroRegistro(String NumeroRegistro) {
        this.NumeroRegistro = NumeroRegistro;
    }
    
    public void imprimir(){
        System.out.println("\n---DATOS DEL ALUMNO---");
        System.out.println("\nIdentidad: "+getIdentidad()+
                           "\nRegistro de Alumno: "+NumeroRegistro);
    }
}
