/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class Profesor extends Persona{
    public String NumeroEmpleado;
    private String Sueldo;

    public Profesor(String NumeroEmpleado, String Sueldo, String Identidad) {
        super(Identidad);
        this.NumeroEmpleado = NumeroEmpleado;
        this.Sueldo = Sueldo;
    }

    public String getNumeroEmpleado() {
        return NumeroEmpleado;
    }

    public void setNumeroEmpleado(String NumeroEmpleado) {
        this.NumeroEmpleado = NumeroEmpleado;
    }

    public String getSueldo() {
        return Sueldo;
    }

    public void setSueldo(String Sueldo) {
        this.Sueldo = Sueldo;
    }
    
    public void mostrarEnPantalla(){
        System.out.println("----DATOS DEL PROFESOR---");
        
        System.out.println("\nIdentidad: "+getIdentidad());
        System.out.println("Numero de Empleado: "+NumeroEmpleado);
        System.out.println("Sueldo: "+Sueldo);
    }
    
    

    
    }
    
