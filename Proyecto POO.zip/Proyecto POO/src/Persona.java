/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class Persona {
    private String Identidad;

    public Persona(String Identidad) {
        this.Identidad = Identidad;
    }

    public String getIdentidad() {
        return Identidad;
    }

    public void setIdentidad(String Identidad) {
        this.Identidad = Identidad;
    }

public static void main (String [] args){
    Profesor profesor = new Profesor("6754","50,000","1234567890");
    profesor.mostrarEnPantalla();
    
    IngenieroSistemas ingeniero = new IngenieroSistemas("0987","2345678901");
    ingeniero.mostrarPantalla();
    
    Alumno alumno = new Alumno("090705","3456789012");
    alumno.imprimir();
}
}