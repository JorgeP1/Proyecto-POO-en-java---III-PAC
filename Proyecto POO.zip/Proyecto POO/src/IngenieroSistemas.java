/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jorge
 */
public class IngenieroSistemas extends Persona {
    public String NumeroColegiado;

    public IngenieroSistemas(String Identidad) {
        super(Identidad);
    }

    public IngenieroSistemas(String NumeroColegiado, String Identidad) {
        super(Identidad);
        this.NumeroColegiado = NumeroColegiado;
    }

    public String getNumeroColegiado() {
        return NumeroColegiado;
    }

    public void setNumeroColegiado(String NumeroColegiado) {
        this.NumeroColegiado = NumeroColegiado;
    }
    
   public void mostrarPantalla(){
       System.out.println("\n---DATOS DEL INGENIERO EN SISTEMAS---");
       System.out.println("\nIdentidad: "+getIdentidad()+
                          "\nNumero de Alfiliado: "+NumeroColegiado);
   }
}
